#!/system/bin/sh
# ============================================================
#  GameTurboBoost - freeze_apps.sh
#  Freeze semua aplikasi non-sistem kecuali WhatsApp
#  Dipanggil saat Game Turbo aktif
# ============================================================

LOG_DIR="/data/local/tmp/GameTurboBoost"
FROZEN_LIST="$LOG_DIR/frozen_packages.txt"

log_f() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [freeze] $1"
}

# ── Daftar paket yang DIKECUALIKAN dari freeze ──────────────
# (tidak akan dibekukan meskipun Game Turbo aktif)
WHITELIST="
com.whatsapp
com.whatsapp.w4b
android
com.android.systemui
com.android.phone
com.android.settings
com.android.inputmethod.latin
com.google.android.inputmethod.latin
com.miui.home
com.miui.launcher
com.miui.securitycenter
com.miui.system
com.android.bluetooth
com.android.wifi
com.android.server.telecom
com.qualcomm.qti.telephonyservice
com.android.providers.telephony
com.android.providers.contacts
com.android.providers.media
com.android.providers.settings
com.android.providers.downloads
com.android.keychain
com.android.packageinstaller
com.android.vending
com.google.android.gms
com.google.android.gsf
com.google.android.gms.policy_sidecar_aps
com.google.android.ext.services
com.google.android.ext.shared
com.google.android.webview
com.android.webview
com.miui.miwallpaper
com.xiaomi.gamebooster
com.miui.gamebooster
com.miui.powerkeeper
com.android.shell
"

# ── Paket yang SELALU difreeze saat gaming (force, ignore whitelist) ────
# Gunakan am set-inactive + force-stop (bukan pm disable, agar mudah dipulihkan)
BLACKLIST="
com.xiaomi.joyose
com.miui.analytics
com.xiaomi.micloud
com.miui.cloudservice
com.miui.cloudbackup
com.miui.weather2
com.miui.miservice
com.google.android.apps.photos
com.google.android.apps.adm
com.google.android.apps.kids.familylink
com.google.android.googlequicksearchbox
com.mi.globalminusscreen
"

# Fungsi cek apakah paket ada di whitelist
is_whitelisted() {
    local pkg="$1"
    echo "$WHITELIST" | grep -qx "$pkg" && return 0
    # Prefix whitelist untuk sistem esensial
    case "$pkg" in
        com.android.*|com.google.android.ext*|com.qualcomm.*) return 0 ;;
    esac
    return 1
}

# Fungsi freeze satu paket (force-stop + disable sementara)
freeze_pkg() {
    local pkg="$1"
    # Suspend proses menggunakan am (lebih aman dari disable)
    am set-inactive "$pkg" true 2>/dev/null
    # Force stop
    am force-stop "$pkg" 2>/dev/null
    echo "$pkg" >> "$FROZEN_LIST"
    log_f "FROZEN: $pkg"
}

# ── Mulai proses freeze ─────────────────────────────────────
log_f "=== Memulai freeze apps ==="

# Bersihkan daftar frozen sebelumnya
> "$FROZEN_LIST"
FROZEN_COUNT=0
SKIP_COUNT=0

# Blacklist: freeze paksa
log_f "--- Memproses blacklist (freeze saat gaming, restore saat selesai) ---"
for pkg in $BLACKLIST; do
    pkg=$(echo "$pkg" | tr -d ' ')
    [ -z "$pkg" ] && continue
    if pm list packages -a 2>/dev/null | grep -q "^package:${pkg}$"; then
        am force-stop "$pkg" 2>/dev/null
        am set-inactive "$pkg" true 2>/dev/null
        echo "$pkg" >> "$FROZEN_LIST"
        log_f "BLACKLIST FROZEN: $pkg"
        FROZEN_COUNT=$((FROZEN_COUNT + 1))
    fi
done

# Ambil semua package yang diinstall user (bukan sistem)
log_f "--- Memproses user apps ---"
USER_PKGS=$(pm list packages -3 2>/dev/null | sed 's/^package://' )

for pkg in $USER_PKGS; do
    pkg=$(echo "$pkg" | tr -d '\r\n ')
    [ -z "$pkg" ] && continue

    # Skip jika ada di whitelist
    if is_whitelisted "$pkg"; then
        log_f "SKIP (whitelist): $pkg"
        SKIP_COUNT=$((SKIP_COUNT + 1))
        continue
    fi

    freeze_pkg "$pkg"
    FROZEN_COUNT=$((FROZEN_COUNT + 1))
done

log_f "=== Freeze selesai. Frozen: $FROZEN_COUNT | Skip: $SKIP_COUNT ==="
