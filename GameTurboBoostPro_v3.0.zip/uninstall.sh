#!/system/bin/sh
# ============================================================
#  Game Turbo Boost Pro - uninstall.sh  v3.0
#  Restore CPU/GPU ke kondisi asal, stop semua daemon
# ============================================================

MODDIR="$(dirname "$0")"
STOCK_DIR="$MODDIR/stock_configs"
LOG_DIR="/data/local/tmp/GameTurboBoost"
LOG_FILE="$LOG_DIR/module.log"
CPU_BASE="/sys/devices/system/cpu/cpufreq"
KGSL="/sys/class/kgsl/kgsl-3d0"

log_u() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [uninstall] $1" >> "$LOG_FILE" 2>/dev/null
}

log_u "=== GameTurboBoost Pro uninstall dimulai ==="

# Stop game_monitor
PID_FILE="$LOG_DIR/monitor.pid"
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    kill "$OLD_PID" 2>/dev/null
    rm -f "$PID_FILE"
    log_u "game_monitor dihentikan (PID: $OLD_PID)."
fi
pkill -f "game_monitor.sh" 2>/dev/null
pkill -f "armpit-valid" 2>/dev/null
log_u "Semua daemon dihentikan."

# Restore CPU governor
restore_policy() {
    local policy="$1"
    local src="$STOCK_DIR/$policy"
    local dir="$CPU_BASE/$policy"
    local gov f

    if [ ! -d "$src" ]; then
        log_u "Backup $policy tidak ada — fallback schedutil."
        echo "schedutil" > "$dir/scaling_governor" 2>/dev/null
        return
    fi
    [ ! -d "$dir" ] && return

    if [ -f "$src/scaling_governor" ]; then
        gov=$(cat "$src/scaling_governor")
        echo "$gov" > "$dir/scaling_governor" 2>/dev/null
        log_u "$policy governor dikembalikan ke: $gov"
    fi
    [ -f "$src/scaling_min_freq" ] && cat "$src/scaling_min_freq" > "$dir/scaling_min_freq" 2>/dev/null
    [ -f "$src/scaling_max_freq" ] && cat "$src/scaling_max_freq" > "$dir/scaling_max_freq" 2>/dev/null
    log_u "$policy max_freq dikembalikan."

    gov=$(cat "$src/scaling_governor" 2>/dev/null)
    if [ -n "$gov" ] && [ -d "$src/tunables" ] && [ -d "$dir/$gov" ]; then
        for f in "$src/tunables"/*; do
            [ -f "$f" ] && cat "$f" > "$dir/$gov/$(basename "$f")" 2>/dev/null
        done
        log_u "$policy tunables dipulihkan."
    fi
}

if [ -d "$STOCK_DIR" ]; then
    restore_policy "policy0"
    restore_policy "policy4"
else
    log_u "stock_configs tidak ada — fallback schedutil manual."
    echo "schedutil" > "$CPU_BASE/policy0/scaling_governor" 2>/dev/null
    echo "schedutil" > "$CPU_BASE/policy4/scaling_governor" 2>/dev/null
fi

# Restore GPU
[ -f "$STOCK_DIR/gpu_governor" ] && \
    cat "$STOCK_DIR/gpu_governor" > "$KGSL/devfreq/governor" 2>/dev/null && \
    log_u "GPU governor dikembalikan."
[ -f "$STOCK_DIR/gpu_default_pwrlevel" ] && \
    cat "$STOCK_DIR/gpu_default_pwrlevel" > "$KGSL/default_pwrlevel" 2>/dev/null
[ -f "$STOCK_DIR/gpu_min_pwrlevel" ] && \
    cat "$STOCK_DIR/gpu_min_pwrlevel" > "$KGSL/min_pwrlevel" 2>/dev/null

# Restore system settings
settings put global disable_default_game_fps_override 0 2>/dev/null
settings put global low_power 0 2>/dev/null
echo 60 > /proc/sys/vm/swappiness 2>/dev/null
for block in /sys/block/sda /sys/block/sdb /sys/block/sdc; do
    [ -f "$block/queue/scheduler" ] && \
    echo "cfq" > "$block/queue/scheduler" 2>/dev/null
done

# Re-enable Joyose
am set-inactive "com.xiaomi.joyose" false 2>/dev/null
pm enable "com.xiaomi.joyose" 2>/dev/null
settings put global joyose_enabled 1 2>/dev/null
log_u "Joyose dipulihkan."

rm -f "$LOG_DIR/freeze_state"
rm -f "$LOG_DIR/frozen_packages.txt"
log_u "=== Uninstall selesai. CPU/GPU dikembalikan ke kondisi asal. ==="
