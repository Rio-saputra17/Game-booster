#!/system/bin/sh
# ============================================================
#  Game Turbo Boost Pro - post-fs-data.sh
#  Early boot: matikan Joyose + siapkan log dir
#  Target: Poco X6 5G (Garnet) | HyperOS 3 | SM7435
# ============================================================

MODDIR="${0%/*}"
LOG_DIR="/data/local/tmp/GameTurboBoost"
LOG_FILE="$LOG_DIR/module.log"

mkdir -p "$LOG_DIR"
chmod 755 "$LOG_DIR"

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [post-fs-data] $1" >> "$LOG_FILE"
}

log_msg "=== GameTurboBoost Pro post-fs-data dimulai ==="

ensure_joyose_disabled() {
    local pkg="com.xiaomi.joyose"
    local i=0

    # Tunggu pm siap (maks ~60 detik)
    while ! pm list packages -a 2>/dev/null | grep -q "package:" && [ $i -lt 20 ]; do
        sleep 3
        i=$((i + 1))
    done

    if pm list packages -a 2>/dev/null | grep -q "$pkg"; then
        am force-stop "$pkg" 2>/dev/null
        am set-inactive "$pkg" true 2>/dev/null
        pm disable-user --user 0 "$pkg" 2>/dev/null
        settings put global joyose_enabled 0 2>/dev/null
        log_msg "Joyose dimatikan di early boot."
    else
        log_msg "Joyose tidak ditemukan — skip."
    fi

    # Battery saver = hard FPS cap, wajib nonaktif sejak boot
    settings put global low_power 0 2>/dev/null
    settings put global low_power_sticky 0 2>/dev/null
    log_msg "Battery saver dipastikan nonaktif."
}

(
    sleep 20
    ensure_joyose_disabled
) &

log_msg "=== post-fs-data selesai ==="
