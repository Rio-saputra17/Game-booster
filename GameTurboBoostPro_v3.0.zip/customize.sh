#!/system/bin/sh
# ============================================================
#  Game Turbo Boost Pro - customize.sh  v3.0
#  Installer: backup CPU/GPU stock + set permissions
#  Target: Poco X6 5G (Garnet) | HyperOS 3 | SM7435-AB
# ============================================================

SKIPUNZIP=1

ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "   Game Turbo Boost Pro v3.0"
ui_print "   FPS Unlock + CPU Gov + Freeze + ARMPIT"
ui_print "   Poco X6 5G (Garnet) | HyperOS 3"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print ""
ui_print "[*] Mengekstrak file module..."
unzip -o "$ZIPFILE" -x 'META-INF/*' -d "$MODPATH" >&2

ui_print "[*] Mengatur izin file..."
set_perm_recursive "$MODPATH"        root root 0755 0644
set_perm "$MODPATH/service.sh"        root root 0755
set_perm "$MODPATH/game_monitor.sh"   root root 0755
set_perm "$MODPATH/freeze_apps.sh"    root root 0755
set_perm "$MODPATH/unfreeze_apps.sh"  root root 0755
set_perm "$MODPATH/post-fs-data.sh"   root root 0755
set_perm "$MODPATH/uninstall.sh"      root root 0755

# Set permission semua binary ARMPIT core
for bin in default balance_oriented battery_oriented performance_oriented gov restore zram armpit-valid; do
    [ -f "$MODPATH/core/$bin" ] && set_perm "$MODPATH/core/$bin" root root 0755
done

# ============================================================
#  BACKUP CPU/GPU STOCK — Non-Destructive Install
#  SM7435: policy0 (4x A55) + policy4 (4x A78)
#  Backup ke $MODPATH/stock_configs/
# ============================================================
STOCK_DIR="$MODPATH/stock_configs"
CPU_BASE="/sys/devices/system/cpu/cpufreq"
KGSL="/sys/class/kgsl/kgsl-3d0"

ui_print ""
ui_print "[*] Menyimpan konfigurasi CPU/GPU asli..."
mkdir -p "$STOCK_DIR"

backup_policy() {
    local policy="$1"
    local dir="$CPU_BASE/$policy"
    local out="$STOCK_DIR/$policy"

    if [ ! -d "$dir" ]; then
        ui_print "    [!] $policy tidak ditemukan — skip."
        return
    fi
    mkdir -p "$out"

    if [ -f "$dir/scaling_governor" ]; then
        cat "$dir/scaling_governor" > "$out/scaling_governor" 2>/dev/null
        ui_print "    [$policy] governor : $(cat "$out/scaling_governor")"
    fi
    if [ -f "$dir/scaling_min_freq" ]; then
        cat "$dir/scaling_min_freq" > "$out/scaling_min_freq" 2>/dev/null
        ui_print "    [$policy] min_freq : $(cat "$out/scaling_min_freq") kHz"
    fi
    if [ -f "$dir/scaling_max_freq" ]; then
        cat "$dir/scaling_max_freq" > "$out/scaling_max_freq" 2>/dev/null
        ui_print "    [$policy] max_freq : $(cat "$out/scaling_max_freq") kHz"
    fi

    # Backup tunables governor
    local gov
    gov=$(cat "$dir/scaling_governor" 2>/dev/null)
    if [ -n "$gov" ] && [ -d "$dir/$gov" ]; then
        mkdir -p "$out/tunables"
        for f in "$dir/$gov"/*; do
            [ -f "$f" ] && cat "$f" > "$out/tunables/$(basename "$f")" 2>/dev/null
        done
        ui_print "    [$policy] tunables '$gov' disimpan."
    fi
}

backup_policy "policy0"
backup_policy "policy4"

# Backup GPU KGSL Adreno 710
if [ -f "$KGSL/default_pwrlevel" ]; then
    cat "$KGSL/default_pwrlevel" > "$STOCK_DIR/gpu_default_pwrlevel" 2>/dev/null
    ui_print "    [GPU] default_pwrlevel : $(cat "$STOCK_DIR/gpu_default_pwrlevel")"
fi
if [ -f "$KGSL/min_pwrlevel" ]; then
    cat "$KGSL/min_pwrlevel" > "$STOCK_DIR/gpu_min_pwrlevel" 2>/dev/null
    ui_print "    [GPU] min_pwrlevel     : $(cat "$STOCK_DIR/gpu_min_pwrlevel")"
fi
if [ -f "$KGSL/devfreq/governor" ]; then
    cat "$KGSL/devfreq/governor" > "$STOCK_DIR/gpu_governor" 2>/dev/null
    ui_print "    [GPU] governor         : $(cat "$STOCK_DIR/gpu_governor")"
fi

ui_print "[✓] Backup CPU/GPU selesai."
ui_print ""
ui_print "[✓] Instalasi selesai!"
ui_print "[!] Reboot diperlukan untuk mengaktifkan module."
ui_print ""
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  Fitur v3.0:"
ui_print "  • FPS Unlock (SurfaceFlinger + HyperOS 3)"
ui_print "  • CPU Gaming: schedhorizon (policy0 max 1958400kHz)"
ui_print "  • CPU Gaming: schedhorizon (policy4 max 2400000kHz)"
ui_print "  • CPU Idle  : walt (hemat baterai)"
ui_print "  • GPU: Adreno 710 msm-adreno-tz"
ui_print "  • ARMPIT: performance saat gaming, balance saat idle"
ui_print "  • VSYNC disable (Adreno-safe)"
ui_print "  • App Freeze/Unfreeze saat gaming"
ui_print "  • Joyose kill + RAM compact + I/O mq-deadline"
ui_print "  • Thermal: >75C idle | <65C gaming kembali"
ui_print "  • Non-destructive: backup & restore CPU/GPU"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
