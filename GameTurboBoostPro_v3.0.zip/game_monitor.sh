#!/system/bin/sh
# ============================================================
#  Game Turbo Boost Pro - game_monitor.sh  v3.0
#  Daemon: monitor Game Turbo + CPU governor + ARMPIT profile
#  Target: Poco X6 5G (Garnet) | HyperOS 3 | SM7435-AB
#  Chipset: Snapdragon 7s Gen 2 | GPU: Adreno 710
#  CPU: 4x Cortex-A55 (policy0) + 4x Cortex-A78 (policy4)
#  RAM: LPDDR4X | Storage: UFS 2.2
#  Governors verified: walt schedhorizon schedutil performance
#    conservative powersave
# ============================================================

MODDIR="$(dirname "$0")"
LOG_DIR="/data/local/tmp/GameTurboBoost"
LOG_FILE="$LOG_DIR/module.log"
STATE_FILE="$LOG_DIR/freeze_state"
FREEZE_SCRIPT="$MODDIR/freeze_apps.sh"
UNFREEZE_SCRIPT="$MODDIR/unfreeze_apps.sh"
STOCK_DIR="$MODDIR/stock_configs"
CORE="$MODDIR/core"

POLL_INTERVAL=3

# ── Thermal thresholds (milli-celsius) ──────────────────────
# SM7435 Snapdragon 7s Gen 2: threshold berdasarkan spesifikasi
THERMAL_CRITICAL=75000   # 75°C → paksa idle governor
THERMAL_RECOVERY=65000   # 65°C → kembali gaming governor
THERMAL_TRIGGERED=0

# ── Paket Game Turbo HyperOS 3 ───────────────────────────────
GAME_TURBO_PACKAGES="
com.xiaomi.gamebooster
com.miui.gamebooster
com.xiaomi.misettings.gamebooster
com.miui.securitycenter
"

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [monitor] $1" >> "$LOG_FILE"
    local size
    size=$(wc -c < "$LOG_FILE" 2>/dev/null || echo 0)
    if [ "$size" -gt 2097152 ]; then
        tail -n 500 "$LOG_FILE" > "${LOG_FILE}.tmp" && mv "${LOG_FILE}.tmp" "$LOG_FILE"
    fi
}

# ============================================================
#  THERMAL MONITORING — Snapdragon thermal zones
# ============================================================
get_cpu_temp() {
    local temp=0
    local t
    for zone in /sys/class/thermal/thermal_zone*/temp; do
        [ -f "$zone" ] || continue
        t=$(cat "$zone" 2>/dev/null)
        [ -z "$t" ] && continue
        # Filter nilai wajar: 1000–120000 milli-C
        [ "$t" -lt 1000 ] 2>/dev/null && continue
        [ "$t" -gt 120000 ] 2>/dev/null && continue
        [ "$t" -gt "$temp" ] 2>/dev/null && temp="$t"
    done
    echo "$temp"
}

# ============================================================
#  RESTORE CPU/GPU KE STOCK CONFIG (dari backup install)
# ============================================================
restore_stock_cpu() {
    log_msg "[STOCK] Mengembalikan CPU/GPU ke backup asli..."
    local CPU_BASE="/sys/devices/system/cpu/cpufreq"
    local policy src dir gov f

    for policy in policy0 policy4; do
        src="$STOCK_DIR/$policy"
        dir="$CPU_BASE/$policy"
        [ ! -d "$src" ] && log_msg "[STOCK] Backup $policy tidak ada — skip." && continue
        [ ! -d "$dir" ] && continue

        if [ -f "$src/scaling_governor" ]; then
            gov=$(cat "$src/scaling_governor")
            echo "$gov" > "$dir/scaling_governor" 2>/dev/null
            log_msg "[STOCK] $policy governor → $gov"
        fi
        [ -f "$src/scaling_min_freq" ] && cat "$src/scaling_min_freq" > "$dir/scaling_min_freq" 2>/dev/null
        [ -f "$src/scaling_max_freq" ] && cat "$src/scaling_max_freq" > "$dir/scaling_max_freq" 2>/dev/null

        gov=$(cat "$src/scaling_governor" 2>/dev/null)
        if [ -n "$gov" ] && [ -d "$src/tunables" ] && [ -d "$dir/$gov" ]; then
            for f in "$src/tunables"/*; do
                [ -f "$f" ] && cat "$f" > "$dir/$gov/$(basename "$f")" 2>/dev/null
            done
            log_msg "[STOCK] $policy tunables '$gov' dipulihkan."
        fi
    done

    local KGSL="/sys/class/kgsl/kgsl-3d0"
    [ -f "$STOCK_DIR/gpu_governor" ] && \
        cat "$STOCK_DIR/gpu_governor" > "$KGSL/devfreq/governor" 2>/dev/null && \
        log_msg "[STOCK] GPU governor → $(cat "$STOCK_DIR/gpu_governor")"
    [ -f "$STOCK_DIR/gpu_default_pwrlevel" ] && \
        cat "$STOCK_DIR/gpu_default_pwrlevel" > "$KGSL/default_pwrlevel" 2>/dev/null
    [ -f "$STOCK_DIR/gpu_min_pwrlevel" ] && \
        cat "$STOCK_DIR/gpu_min_pwrlevel" > "$KGSL/min_pwrlevel" 2>/dev/null

    log_msg "[STOCK] Restore CPU/GPU selesai."
}

# ============================================================
#  DETEKSI GAME TURBO AKTIF — 5 metode
# ============================================================
is_game_turbo_active() {
    local prop_val state focused svc_running pkg

    prop_val=$(getprop sys.game_turbo.active 2>/dev/null)
    [ "$prop_val" = "1" ] && return 0

    prop_val=$(getprop debug.game_turbo.pid 2>/dev/null)
    [ -n "$prop_val" ] && [ "$prop_val" != "0" ] && return 0

    for pkg in $GAME_TURBO_PACKAGES; do
        state=$(dumpsys activity "$pkg" 2>/dev/null | grep -c "mResumed=true")
        [ "$state" -gt 0 ] && return 0
    done

    focused=$(dumpsys window windows 2>/dev/null | grep -i "mCurrentFocus" | head -1)
    for pkg in $GAME_TURBO_PACKAGES; do
        echo "$focused" | grep -q "$pkg" && return 0
    done

    for pkg in $GAME_TURBO_PACKAGES; do
        svc_running=$(dumpsys activity services "$pkg" 2>/dev/null | grep -c "ServiceRecord")
        [ "$svc_running" -gt 0 ] && return 0
    done

    prop_val=$(getprop persist.sys.game_status 2>/dev/null)
    [ "$prop_val" = "running" ] && return 0

    return 1
}

get_freeze_state() { [ -f "$STATE_FILE" ] && cat "$STATE_FILE" || echo "unfrozen"; }
set_freeze_state() { echo "$1" > "$STATE_FILE"; }

# ============================================================
#  unlock_fps() — Gaming profile: schedhorizon + Adreno max
#  SM7435 verified frequencies:
#    policy0 (A55): min 691200, max 1958400 kHz
#    policy4 (A78): min 691200, max 2400000 kHz
#  Adreno 710 KGSL: msm-adreno-tz governor
# ============================================================
unlock_fps() {
    log_msg "[GAMING] Aktifkan gaming profile (schedhorizon + ARMPIT perf)..."

    # ── FPS unlock: HyperOS 3 bypass ──
    settings put global disable_default_game_fps_override 1 2>/dev/null
    setprop debug.sf.disable_client_composition_cache 1 2>/dev/null

    # SurfaceFlinger FPS cap removal (dua kali — HyperOS 3 quirk)
    service call SurfaceFlinger 1034 i32 0 2>/dev/null
    sleep 1
    service call SurfaceFlinger 1034 i32 0 2>/dev/null

    # ── GPU: Adreno 710 full power ──
    # msm-adreno-tz: governor resmi Qualcomm, optimal untuk gaming Adreno
    echo "msm-adreno-tz" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null
    echo 0 > /sys/class/kgsl/kgsl-3d0/min_pwrlevel 2>/dev/null
    echo 0 > /sys/class/kgsl/kgsl-3d0/default_pwrlevel 2>/dev/null
    echo 0 > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 2>/dev/null

    # ── CPU: schedhorizon untuk gaming ──
    # schedhorizon: Qualcomm CAF governor, lebih agresif dari schedutil
    echo "schedhorizon" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 2>/dev/null
    echo "schedhorizon" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor 2>/dev/null
    # Max freq verified dari device Garnet
    echo 1958400 > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null
    echo 2400000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
    echo 691200  > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq 2>/dev/null
    echo 691200  > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq 2>/dev/null

    # ── Rendering: skiagl optimal untuk Adreno 710 + LPDDR4X ──
    setprop debug.hwui.renderer "skiagl" 2>/dev/null
    setprop persist.sys.perf.topAppRenderThreadBoost.enable "true" 2>/dev/null
    setprop debug.sf.enable_advanced_sf_phase_offset 1 2>/dev/null

    # ── ARMPIT: stop armpit-valid daemon saat gaming ──
    pkill -f "armpit-valid" 2>/dev/null
    log_msg "[ARMPIT] armpit-valid daemon dihentikan saat gaming."

    # ── ARMPIT: performance_oriented biarkan jalan dulu ──
    # Binary ini butuh ~3 detik dan kemungkinan reset governor.
    # Jalankan dia DULU, setelah selesai kita timpa governor kita.
    if [ -x "$CORE/performance_oriented" ]; then
        "$CORE/performance_oriented" >> "$LOG_FILE" 2>&1
        log_msg "[ARMPIT] performance_oriented selesai."
    fi

    # ── CPU governor ditulis ULANG setelah ARMPIT selesai ──
    # Ini memastikan schedhorizon yang menang, bukan apapun yang di-set ARMPIT
    echo "schedhorizon" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 2>/dev/null
    echo "schedhorizon" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor 2>/dev/null
    echo 1958400 > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null
    echo 2400000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
    echo 691200  > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq 2>/dev/null
    echo 691200  > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq 2>/dev/null
    # GPU juga ditulis ulang
    echo "msm-adreno-tz" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null
    echo 0 > /sys/class/kgsl/kgsl-3d0/min_pwrlevel 2>/dev/null
    echo 0 > /sys/class/kgsl/kgsl-3d0/default_pwrlevel 2>/dev/null
    log_msg "[GAMING] Governor ditulis ulang setelah ARMPIT: schedhorizon confirmed."

    THERMAL_TRIGGERED=0
    log_msg "[GAMING] Profile aktif: schedhorizon | A55 max 1958400 | A78 max 2400000 | GPU msm-adreno-tz."
}

# ============================================================
#  apply_idle_governor() — Idle profile: walt + ARMPIT balance
#  Dipakai saat: tidak gaming ATAU thermal throttle
# ============================================================
apply_idle_governor() {
    local reason="$1"
    log_msg "[IDLE] Menerapkan idle governor (walt). Alasan: $reason"

    # walt: Qualcomm CAF governor, efisien untuk daily use
    echo "walt" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 2>/dev/null
    echo "walt" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor 2>/dev/null

    # Kembalikan max_freq dari backup, fallback ke nilai stock Garnet
    if [ -f "$STOCK_DIR/policy0/scaling_max_freq" ]; then
        cat "$STOCK_DIR/policy0/scaling_max_freq" > \
            /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null
    else
        echo 1958400 > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null
    fi
    if [ -f "$STOCK_DIR/policy4/scaling_max_freq" ]; then
        cat "$STOCK_DIR/policy4/scaling_max_freq" > \
            /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
    else
        echo 2400000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
    fi
    echo 691200 > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq 2>/dev/null
    echo 691200 > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq 2>/dev/null

    # GPU: turun ke level efisien
    echo 3 > /sys/class/kgsl/kgsl-3d0/default_pwrlevel 2>/dev/null
    echo 6 > /sys/class/kgsl/kgsl-3d0/min_pwrlevel 2>/dev/null

    # ── ARMPIT: balance_oriented profile untuk idle ──
    if [ -x "$CORE/balance_oriented" ]; then
        "$CORE/balance_oriented" >> "$LOG_FILE" 2>&1
        log_msg "[ARMPIT] balance_oriented profile aktif."
    fi

    # ── ARMPIT: restart armpit-valid daemon setelah gaming ──
    # Cek dulu apakah sudah jalan — hindari multiple instance
    if ! pidof armpit-valid >/dev/null 2>&1; then
        if [ -x "$CORE/armpit-valid" ]; then
            nohup "$CORE/armpit-valid" >> "$LOG_FILE" 2>&1 &
            log_msg "[ARMPIT] armpit-valid daemon di-restart (PID: $!)."
        fi
    else
        log_msg "[ARMPIT] armpit-valid sudah berjalan — skip restart."
    fi

    log_msg "[IDLE] Idle governor (walt) + ARMPIT balance diterapkan."
}

# ============================================================
#  restore_fps() — Kembalikan FPS setting ke normal
# ============================================================
restore_fps() {
    log_msg "[FPS] Mengembalikan setting FPS normal..."
    settings put global disable_default_game_fps_override 0 2>/dev/null
    apply_idle_governor "game session ended"
    log_msg "[FPS] Setting FPS normal dipulihkan."
}

# ============================================================
#  gaming_tweaks() — System-level tuning saat gaming
#  Target: SM7435 + UFS 2.2 + LPDDR4X
# ============================================================
gaming_tweaks() {
    log_msg "[TWEAK] gaming_tweaks() dimulai..."

    # Joyose: mati saat gaming (re-enable setelah selesai)
    am force-stop "com.xiaomi.joyose" 2>/dev/null
    am set-inactive "com.xiaomi.joyose" true 2>/dev/null
    settings put global joyose_enabled 0 2>/dev/null

    # Battery saver wajib nonaktif
    settings put global low_power 0 2>/dev/null
    settings put global low_power_sticky 0 2>/dev/null

    # RAM: kompaksi sebelum game mulai
    echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
    # Swappiness 40: kurangi swap → latency lebih rendah untuk LPDDR4X
    echo 40 > /proc/sys/vm/swappiness 2>/dev/null

    # I/O: mq-deadline konsisten untuk UFS 2.2 (sda/sdb pada SM7435)
    for block in /sys/block/sda /sys/block/sdb /sys/block/sdc; do
        [ -f "$block/queue/scheduler" ] && \
        echo "mq-deadline" > "$block/queue/scheduler" 2>/dev/null
    done
    log_msg "[TWEAK] I/O scheduler: mq-deadline."

    setprop persist.sys.bg_apps.limit 0 2>/dev/null
    log_msg "[TWEAK] gaming_tweaks() selesai."
}

# ============================================================
#  restore_tweaks() — Kembalikan system settings ke normal
# ============================================================
restore_tweaks() {
    log_msg "[TWEAK] restore_tweaks() dimulai..."

    # Re-enable Joyose
    am set-inactive "com.xiaomi.joyose" false 2>/dev/null
    pm enable "com.xiaomi.joyose" 2>/dev/null

    # Swappiness kembali ke default Android
    echo 60 > /proc/sys/vm/swappiness 2>/dev/null

    # I/O scheduler kembali ke default
    for block in /sys/block/sda /sys/block/sdb /sys/block/sdc; do
        [ -f "$block/queue/scheduler" ] && \
        echo "cfq" > "$block/queue/scheduler" 2>/dev/null
    done

    log_msg "[TWEAK] restore_tweaks() selesai."
}

# ============================================================
#  THERMAL PROTECTION
#  KRITIS  ≥75°C → paksa idle governor
#  RECOVERY <65°C → kembali gaming governor
# ============================================================
check_thermal() {
    local temp temp_c
    temp=$(get_cpu_temp)
    [ "$temp" -eq 0 ] 2>/dev/null && return

    if [ "$THERMAL_TRIGGERED" -eq 0 ] && [ "$temp" -ge "$THERMAL_CRITICAL" ] 2>/dev/null; then
        temp_c=$((temp / 1000))
        log_msg "[THERMAL] ⚠ KRITIS: ${temp_c}°C ≥ 75°C — paksa idle governor!"
        apply_idle_governor "thermal critical ${temp_c}C"
        THERMAL_TRIGGERED=1

    elif [ "$THERMAL_TRIGGERED" -eq 1 ] && [ "$temp" -lt "$THERMAL_RECOVERY" ] 2>/dev/null; then
        temp_c=$((temp / 1000))
        log_msg "[THERMAL] ✓ Suhu normal: ${temp_c}°C < 65°C — pulihkan gaming governor."
        unlock_fps
        THERMAL_TRIGGERED=0
    fi
}

# ── Main loop ───────────────────────────────────────────────
log_msg "=== game_monitor v3.0 dimulai. Poll: ${POLL_INTERVAL}s ==="
log_msg "=== Garnet SM7435 | Gaming: schedhorizon | Idle: walt ==="
log_msg "=== policy0(A55) max 1958400kHz | policy4(A78) max 2400000kHz ==="
log_msg "=== Thermal: KRITIS >=75C → idle | RECOVERY <65C → gaming ==="
log_msg "=== ARMPIT: perf saat gaming | balance saat idle ==="

PREV_STATE="unfrozen"
set_freeze_state "unfrozen"

while true; do
    if is_game_turbo_active; then
        if [ "$PREV_STATE" != "frozen" ]; then
            log_msg ">>> Game Turbo AKTIF — mulai optimasi gaming..."

            # Urutan KRITIS — jangan diubah:
            # 1. Freeze → bebaskan RAM
            sh "$FREEZE_SCRIPT" >> "$LOG_FILE" 2>&1

            # 2. System tweaks
            gaming_tweaks

            # 3. Jeda 2 detik → tunggu SFB selesai override governor
            sleep 2

            # 4. Gaming governor + ARMPIT perf TERAKHIR
            unlock_fps

            set_freeze_state "frozen"
            PREV_STATE="frozen"
            log_msg ">>> Semua optimasi gaming AKTIF."
        else
            # Sudah gaming — monitor thermal setiap siklus
            check_thermal
        fi
    else
        if [ "$PREV_STATE" = "frozen" ]; then
            log_msg ">>> Game Turbo TIDAK AKTIF — restore..."

            THERMAL_TRIGGERED=0
            restore_fps
            restore_tweaks
            sh "$UNFREEZE_SCRIPT" >> "$LOG_FILE" 2>&1

            set_freeze_state "unfrozen"
            PREV_STATE="unfrozen"
            log_msg ">>> Semua setting normal DIPULIHKAN."
        fi
    fi

    sleep "$POLL_INTERVAL"
done
