#!/system/bin/sh
# ============================================================
#  Game Turbo Boost Pro - service.sh  v3.0
#  Boot entry point: ARMPIT baseline + game_monitor daemon
#  Target: Poco X6 5G (Garnet) | HyperOS 3 | SM7435
# ============================================================

MODDIR="${0%/*}"
LOG_DIR="/data/local/tmp/GameTurboBoost"
LOG_FILE="$LOG_DIR/module.log"
PID_FILE="$LOG_DIR/monitor.pid"
CORE="$MODDIR/core"

mkdir -p "$LOG_DIR"

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [service] $1" >> "$LOG_FILE"
}

log_msg "=== GameTurboBoost Pro service.sh dimulai ==="

# Tunggu boot selesai + sistem stabil
wait_boot() {
    local i=0
    while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 60 ]; do
        sleep 3
        i=$((i + 1))
    done
    sleep 10
}

wait_boot
log_msg "Boot selesai."

# ── Buat compatibility path untuk binary ARMPIT ────────────
# Binary core/ hardcode /data/adb/modules/armpit/ sebagai working dir.
# Buat symlink agar binary bisa tulis mode.txt dll ke path yg diharapkan.
ARMPIT_COMPAT="/data/adb/modules/armpit"
mkdir -p "$ARMPIT_COMPAT" 2>/dev/null
if [ ! -L "$ARMPIT_COMPAT/core" ]; then
    ln -sf "$MODDIR/core" "$ARMPIT_COMPAT/core" 2>/dev/null
fi
log_msg "ARMPIT compat: $ARMPIT_COMPAT/core -> $MODDIR/core"

# ── Set permission semua binary core ──────────────────────
chmod 0755 "$CORE/default"             2>/dev/null
chmod 0755 "$CORE/balance_oriented"    2>/dev/null
chmod 0755 "$CORE/battery_oriented"    2>/dev/null
chmod 0755 "$CORE/performance_oriented" 2>/dev/null
chmod 0755 "$CORE/gov"                 2>/dev/null
chmod 0755 "$CORE/restore"             2>/dev/null
chmod 0755 "$CORE/zram"                2>/dev/null
chmod 0755 "$CORE/armpit-valid"        2>/dev/null
log_msg "Permission binary core di-set."

# ── VSYNC disable — Snapdragon/Adreno 710 specific ────────
# Hanya set prop yang sudah ada di device (safe, tidak crash)
apply_vsync_tweaks() {
    log_msg "[VSYNC] Menerapkan VSYNC disable tweaks..."
    local applied=0

    # Iterasi manual (POSIX sh — tidak pakai bash array)
    for entry in \
        "debug.cpurend.vsync:false" \
        "debug.egl.vsync:false" \
        "debug.hwui.vsync:false" \
        "debug.hwui.disable_vsync:true" \
        "debug.hwui.skip_vsync:true" \
        "debug.sf.disable_vsync:true" \
        "debug.egl.swapinterval:0" \
        "debug.hwui.render_thread:false" \
        "debug.sf.disable_backpressure:1" \
        "debug.sf.enable_gl_backpressure:0" \
        "vendor.debug.egl.vsync:false" \
        "vendor.debug.sf.vsync:false" \
        "persist.sys.gpu_rendering:opengl"
    do
        local key val current
        key="${entry%%:*}"
        val="${entry##*:}"
        current=$(getprop "$key" 2>/dev/null)
        if [ -n "$current" ]; then
            setprop "$key" "$val" 2>/dev/null
            applied=$((applied + 1))
        fi
    done
    # vendor.debug.mali.* — hanya ada di Mali GPU, skip untuk Adreno 710
    log_msg "[VSYNC] Selesai. Applied: $applied props."
}

apply_vsync_tweaks

# ── ARMPIT: Terapkan baseline profile (default → balance) ──
# Urutan: default dulu → lalu balance_oriented
# Ini menetapkan baseline system tuning sebelum game_monitor jalan
log_msg "[ARMPIT] Menjalankan core/default..."
"$CORE/default" >> "$LOG_FILE" 2>&1
if [ $? -eq 0 ]; then
    log_msg "[ARMPIT] core/default selesai."
else
    log_msg "[ARMPIT] core/default gagal atau tidak kompatibel — skip."
fi

sleep 2

log_msg "[ARMPIT] Menjalankan core/balance_oriented..."
"$CORE/balance_oriented" >> "$LOG_FILE" 2>&1
if [ $? -eq 0 ]; then
    log_msg "[ARMPIT] core/balance_oriented selesai."
else
    log_msg "[ARMPIT] core/balance_oriented gagal atau tidak kompatibel — skip."
fi

sleep 5

# ── ARMPIT: Jalankan armpit-valid daemon ──────────────────
log_msg "[ARMPIT] Menjalankan armpit-valid daemon..."
nohup "$CORE/armpit-valid" >> "$LOG_FILE" 2>&1 &
ARMPIT_PID=$!
log_msg "[ARMPIT] armpit-valid PID: $ARMPIT_PID"

# ── Kill instance lama game_monitor ───────────────────────
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    kill "$OLD_PID" 2>/dev/null
    rm -f "$PID_FILE"
fi

# ── Launch game_monitor daemon ─────────────────────────────
sh "$MODDIR/game_monitor.sh" &
MONITOR_PID=$!
echo "$MONITOR_PID" > "$PID_FILE"
log_msg "game_monitor.sh PID: $MONITOR_PID"

log_msg "=== service.sh selesai. Semua daemon aktif. ==="
