#!/system/bin/sh
# ============================================================
#  GameTurboBoost - unfreeze_apps.sh
#  Pulihkan semua aplikasi yang dibekukan ke kondisi normal
#  Dipanggil saat Game Turbo tidak aktif / selesai gaming
# ============================================================

LOG_DIR="/data/local/tmp/GameTurboBoost"
FROZEN_LIST="$LOG_DIR/frozen_packages.txt"

log_u() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [unfreeze] $1"
}

log_u "=== Memulai unfreeze apps ==="

if [ ! -f "$FROZEN_LIST" ]; then
    log_u "File frozen_packages.txt tidak ditemukan, tidak ada yang perlu di-unfreeze."
    exit 0
fi

UNFREEZE_COUNT=0

while IFS= read -r line; do
    pkg=$(echo "$line" | cut -d':' -f1 | tr -d ' \r\n')
    [ -z "$pkg" ] && continue

    # Pulihkan inactive state — berlaku untuk semua app termasuk Joyose
    am set-inactive "$pkg" false 2>/dev/null
    am start-user 0 2>/dev/null

    log_u "UNFROZEN: $pkg"
    UNFREEZE_COUNT=$((UNFREEZE_COUNT + 1))
done < "$FROZEN_LIST"

# Bersihkan daftar frozen
> "$FROZEN_LIST"

log_u "=== Unfreeze selesai. Restored: $UNFREEZE_COUNT apps (termasuk Joyose) ==="

